import React from "react";
import ReactDOM from "react-dom/client";

function Header() {
    return <h1>Fyrdiana's Pizza Co.</h1>
};

function Pizza() {
    return(
        <div>
            <img SRC="/pizzas/spinaci.jpg"></img>
            <h3>Pizza Spinaci</h3>
            <h6>Tomato, mozarella, spinach, and rocotta cheese</h6>
            <h6>10</h6>
        </div>
        
    );
};


function App(){
    return (
        <div>
            <Header />
            <Pizza />
            <Pizza />
        </div>
    )
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
